package com.example.homework;

import android.view.LayoutInflater;
import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

public class ActivityHomeBinding {
    public View homeTab;
    public View myTab;
    public View fabCreate;
    public View createVoteLayout;
    public View myVotesLayout;
    public View voteTemplatesLayout;
    public View statisticsLayout;
    public RecyclerView voteRecyclerView;

    public static ActivityHomeBinding inflate(LayoutInflater layoutInflater) {
        return null;
    }

    public int getRoot() {
        return 0;
    }
}
