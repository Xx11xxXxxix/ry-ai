package com.example.homework;

import android.app.assist.AssistStructure;
import android.view.LayoutInflater;
import android.view.View;

public class ActivityLoginBinding {
    public View homeTab;
    public View myTab;
    public View wechatLoginButton;
    public AssistStructure.ViewNode agreementCheckBox;
    public View accountLoginButton;

    public static ActivityLoginBinding inflate(LayoutInflater layoutInflater) {
        return null;
    }

    public int getRoot() {
        return 0;
    }
}
