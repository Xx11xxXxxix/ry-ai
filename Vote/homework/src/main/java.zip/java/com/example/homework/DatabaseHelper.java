  package com.example.homework;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    // 数据库名称
    private static final String DB_NAME = "QuestionnaireDB";
    // 数据库版本
    private static final int DB_VERSION = 2; // 更新版本号
    // 用户表
    private static final String TABLE_USER = "user";
    private static final String USER_ID = "id";
    private static final String USER_EMAIL = "email";
    private static final String USER_PASSWORD = "password";
    
    // 投票表
    private static final String TABLE_VOTE = "vote";
    private static final String VOTE_ID = "id";
    private static final String VOTE_TITLE = "title";
    private static final String VOTE_DESCRIPTION = "description";
    private static final String VOTE_CREATOR_ID = "creator_id";
    private static final String VOTE_CREATED_AT = "created_at";

    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // 创建用户表
        String createUserTable = "CREATE TABLE " + TABLE_USER + " (" +
                USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                USER_EMAIL + " TEXT UNIQUE, " +
                USER_PASSWORD + " TEXT)";
        db.execSQL(createUserTable);
        
        // 创建投票表
        String createVoteTable = "CREATE TABLE " + TABLE_VOTE + " (" +
                VOTE_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                VOTE_TITLE + " TEXT NOT NULL, " +
                VOTE_DESCRIPTION + " TEXT, " +
                VOTE_CREATOR_ID + " INTEGER, " +
                VOTE_CREATED_AT + " DATETIME DEFAULT CURRENT_TIMESTAMP, " +
                "FOREIGN KEY (" + VOTE_CREATOR_ID + ") REFERENCES " + TABLE_USER + "(" + USER_ID + "))";
        db.execSQL(createVoteTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // 升级数据库时删除旧表
        if (oldVersion < 2) {
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_VOTE);
            db.execSQL("DROP TABLE IF EXISTS " + TABLE_USER);
            onCreate(db);
        }
    }

    // 注册用户
    public boolean registerUser(String email, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(USER_EMAIL, email);
        values.put(USER_PASSWORD, password);
        // 插入数据
        long result = db.insert(TABLE_USER, null, values);
        db.close();
        // 插入成功返回true
        return result != -1;
    }

    // 检查用户登录
    public boolean checkUser(String email, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USER, new String[]{USER_ID},
                USER_EMAIL + "=? AND " + USER_PASSWORD + "=?",
                new String[]{email, password},
                null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();
        return exists;
    }
    
    // 创建投票
    public boolean createVote(String title, String description, int creatorId) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(VOTE_TITLE, title);
        values.put(VOTE_DESCRIPTION, description);
        values.put(VOTE_CREATOR_ID, creatorId);
        
        long result = db.insert(TABLE_VOTE, null, values);
        db.close();
        return result != -1;
    }
    
    // 获取用户的投票列表
    public List<Vote> getUserVotes(int userId) {
        List<Vote> votes = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        
        Cursor cursor = db.query(TABLE_VOTE, 
                new String[]{VOTE_ID, VOTE_TITLE, VOTE_DESCRIPTION, VOTE_CREATED_AT},
                VOTE_CREATOR_ID + "=?",
                new String[]{String.valueOf(userId)},
                null, null, VOTE_CREATED_AT + " DESC");
                
        if (cursor.moveToFirst()) {
            do {
                Vote vote = new Vote();
                vote.setId(cursor.getInt(0));
                vote.setTitle(cursor.getString(1));
                vote.setDescription(cursor.getString(2));
                vote.setCreatedAt(cursor.getString(3));
                votes.add(vote);
            } while (cursor.moveToNext());
        }
        
        cursor.close();
        db.close();
        return votes;
    }
    
    // 获取用户参与的投票列表（模拟实现）
    public List<Vote> getParticipatedVotes(int userId) {
        // 目前暂时复用getUserVotes方法，实际项目中应该有单独的参与投票表
        // 这里可以根据需要进行扩展
        return getUserVotes(userId);
    }
    
    // 添加隐藏投票功能（用于记录用户隐藏的投票）
    public boolean addHiddenVote(int userId, int voteId) {
        // 在实际项目中，这里应该有一个单独的表来存储用户隐藏的投票
        // 暂时只提供方法签名，供将来扩展
        return true;
    }
    
    // 获取投票详情
    public Vote getVoteById(int voteId) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_VOTE,
                new String[]{VOTE_ID, VOTE_TITLE, VOTE_DESCRIPTION, VOTE_CREATED_AT},
                VOTE_ID + "=?",
                new String[]{String.valueOf(voteId)},
                null, null, null);
        
        Vote vote = null;
        if (cursor.moveToFirst()) {
            vote = new Vote();
            vote.setId(cursor.getInt(0));
            vote.setTitle(cursor.getString(1));
            vote.setDescription(cursor.getString(2));
            vote.setCreatedAt(cursor.getString(3));
        }
        
        cursor.close();
        db.close();
        return vote;
    }
    
    // 内部类表示投票
    public static class Vote {
        private int id;
        private String title;
        private String description;
        private String createdAt;
        
        public int getId() {
            return id;
        }
        
        public void setId(int id) {
            this.id = id;
        }
        
        public String getTitle() {
            return title;
        }
        
        public void setTitle(String title) {
            this.title = title;
        }
        
        public String getDescription() {
            return description;
        }
        
        public void setDescription(String description) {
            this.description = description;
        }
        
        public String getCreatedAt() {
            return createdAt;
        }
        
        public void setCreatedAt(String createdAt) {
            this.createdAt = createdAt;
        }
    }
}