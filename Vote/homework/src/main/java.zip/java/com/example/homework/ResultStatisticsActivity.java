package com.example.homework;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.homework.databinding.ActivityResultStatisticsBinding;
import com.google.android.material.card.MaterialCardView;
import java.util.Random;

public class ResultStatisticsActivity extends AppCompatActivity {
    private ActivityResultStatisticsBinding binding;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityResultStatisticsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // 初始化数据库助手
        dbHelper = new DatabaseHelper(this);

        // 返回按钮点击事件
        binding.btnBack.setOnClickListener(v -> finish());
        
        // 初始化统计数据
        initStatisticsData();
    }
    
    /**
     * 初始化统计数据
     */
    private void initStatisticsData() {
        // 设置投票标题（模拟从上一个页面传递过来的数据）
        String voteTitle = getIntent().getStringExtra("vote_title");
        if (voteTitle != null) {
            binding.tvVoteTitle.setText(voteTitle);
        } else {
            binding.tvVoteTitle.setText("年度最佳员工评选");
        }
        
        // 设置总参与人数
        binding.tvTotalParticipants.setText("245人");
        
        // 添加选项统计数据
        addOptionStatistics();
    }
    
    /**
     * 添加选项统计数据
     */
    private void addOptionStatistics() {
        // 清空容器
        binding.optionsContainer.removeAllViews();
        
        // 模拟选项数据
        String[] options = {"张三", "李四", "王五", "赵六"};
        int[] votes = {45, 38, 62, 16};
        int totalVotes = 161; // 总票数
        
        for (int i = 0; i < options.length; i++) {
            // 创建选项统计视图
            View optionView = LayoutInflater.from(this).inflate(R.layout.item_vote_option, null);
            
            // 查找视图组件
            TextView optionText = optionView.findViewById(R.id.optionText);
            TextView voteCountText = optionView.findViewById(R.id.voteCountText);
            TextView votePercentageText = optionView.findViewById(R.id.votePercentageText);
            ProgressBar progressBar = optionView.findViewById(R.id.voteProgressBar);
            
            // 设置数据
            optionText.setText(options[i]);
            voteCountText.setText(votes[i] + "票");
            
            // 计算百分比
            double percentage = (double) votes[i] / totalVotes * 100;
            votePercentageText.setText(String.format("%.1f", percentage) + "%");
            
            // 设置进度条
            progressBar.setProgress((int) percentage);
            progressBar.setVisibility(View.VISIBLE);
            
            // 为进度条设置颜色以区分不同选项
            if (i == 0) {
                progressBar.setProgressTintList(getResources().getColorStateList(R.color.primary_gradient_end));
            } else if (i == 1) {
                progressBar.setProgressTintList(getResources().getColorStateList(R.color.secondary_gradient_start));
            } else if (i == 2) {
                progressBar.setProgressTintList(getResources().getColorStateList(R.color.success));
            } else {
                progressBar.setProgressTintList(getResources().getColorStateList(R.color.warning));
            }
            
            // 将视图添加到容器中
            binding.optionsContainer.addView(optionView);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        binding = null;
    }
}